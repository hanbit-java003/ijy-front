// commonJS
// AMD (Asynchronous Module Definition)
// Bundler
var calc = require('./calculator');

alert('hello');
console.log(calc.add(4, 5));
console.log(calc.minus(4, 5));
