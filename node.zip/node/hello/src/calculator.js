function plus(x, y) {
    return x + y;
}

exports.add = plus;

exports.minus = function (x, y) {
  return x - y;
};