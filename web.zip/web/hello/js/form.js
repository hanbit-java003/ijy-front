/**
 * Created by 1027 on 2017-06-14.
 */
var btnLogin = document.querySelector("#btnLogin");
btnLogin.onclick = function(event) {
    event.preventDefault();

    if (document.querySelector("#txtId").value === "") {
        alert("아이디를 입력하세요.");
        return;
    }
    else if (document.querySelector("#txtPw").value === "") {
        alert("비밀번호를 입력하세요.");
        return;
    }

    document.querySelector("#frmLogin").submit();
};