$(function() {
   $('#show-times-table').on('click', function () {
        var textDan = $('#dan');
        var dan = parseInt(textDan.val());

        var result = $('#result');

        if (isNaN(dan)) {
            result.addClass('error');
            result.html('숫자만 입력하세요.');
            textDan.val('');
            return;
        }

        var output = '';

        for (var i=1; i<=9; i++) {
            output += dan + ' x ' + i + ' = ' + (dan*i) + '<br>';
        }

        result.removeClass('error');
        result.html(output);
    });
});
