var gulp = require('gulp');
var all = require('gulp-all');
var del = require('del');
var runSequence = require('run-sequence');
var uglify = require('gulp-uglify');

gulp.task('clean', function (done) {
   del(['./dist']).then(function () {
       done();
   })
});

gulp.task('copy-jquery', function () {
    return gulp.src('./node_modules/jquery/dist/jquery.min.js')
        .pipe(gulp.dest('./dist/assets/jquery'));
});

gulp.task('copy-bootstrap', function () {
    return gulp.src('./node_modules/bootstrap/dist/**/*')
        .pipe(gulp.dest('./dist/assets/bootstrap'));
});

gulp.task('copy-font-awesome', function () {
    return all(
        gulp.src('./node_modules/font-awesome/css/**/*')
            .pipe(gulp.dest('./dist/assets/font-awesome/css')),
        gulp.src('./node_modules/font-awesome/fonts/**/*')
            .pipe(gulp.dest('./dist/assets/font-awesome/fonts'))
    );
});

gulp.task('copy-javascript', function () {
    return gulp.src('./src/js/**/*.js')
        .pipe(uglify())
        .pipe(gulp.dest('./dist/js'));
})

gulp.task('copy-misc', function () {
    return gulp.src(['./src/**/*', '!./src/js/**/*.js'])
        .pipe(gulp.dest('./dist'));
});

gulp.task('copy', [
    'copy-jquery',
    'copy-bootstrap',
    'copy-font-awesome',
    'copy-javascript',
    'copy-misc'
]);

gulp.task('default', function (done) {
    runSequence('clean','copy',done);
});